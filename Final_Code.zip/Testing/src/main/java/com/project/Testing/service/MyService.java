package com.project.Testing.service;


public interface MyService {
}
