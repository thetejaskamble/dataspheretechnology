package com.project.Testing.serviceImpl;

import com.project.Testing.service.MyService;

public class MyServiceImpl implements MyService {
}
