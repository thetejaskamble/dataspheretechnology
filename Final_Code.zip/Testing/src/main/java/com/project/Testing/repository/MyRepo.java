package com.project.Testing.repository;

public interface MyRepo {
    // repository methods
}