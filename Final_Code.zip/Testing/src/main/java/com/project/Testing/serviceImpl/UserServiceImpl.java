package com.project.Testing.serviceImpl;

import com.project.Testing.model.User;
import com.project.Testing.repository.UserRepo;
import com.project.Testing.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.apache.logging.log4j.message.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.thymeleaf.model.IModel;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepo userRepository;

    public UserServiceImpl(UserRepo userRepository, User user) {
        this.userRepository = userRepository;
        this.user = user;
    }

    @Autowired
    public BCryptPasswordEncoder bCryptPasswordEncoder;

    @Override
    public User registerUser(User user) throws Exception {
        // Additional validation and processing can be done here
        User existingUser = userRepository.findByEmail(user.getEmail());

        if (existingUser != null) {
            return null;
        } else{
            String email = user.getEmail();
            user.setEmail(email.toLowerCase());
            String password = bCryptPasswordEncoder.encode(user.getPassword());
            user.setPassword(password);
            return userRepository.save(user);
        }

    }

    @Override
    public User findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    @Override
    public String getString() {
        return "Email already exists!";
    }

    private final User user;

    @Autowired
    public UserServiceImpl(User user) {
        this.user = user;
    }

    @Override
    public void removeSessionMessage(){
        HttpSession session = ((ServletRequestAttributes)(RequestContextHolder.getRequestAttributes())).getRequest().getSession();
        session.removeAttribute("msg");
    }

}